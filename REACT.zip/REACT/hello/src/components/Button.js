import React from 'react';

const Button1 = () => {
    return (
       <button>Click</button>
    );
};

export default Button1;