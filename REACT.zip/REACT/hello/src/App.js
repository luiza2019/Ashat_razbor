import React, { useState } from "react"
import Button1 from "./components/Button"
import Input from "./components/Input"
import View from "./components/View"

function App() {
  const [todos, setTodos] = useState([])
  function addTask(task) {
    let obj =
    {
      title: task,
      id: Date.now()
    }
    let todosArr = [...todos, obj]
    setTodos(todosArr)
  }
  console.log(todos)
  return (
    <>
      <Input addTask={addTask} />
      {/* <Button1 /> */}
      <View todos={todos} />
    </>
  )
}

export default App




